package com.example.childrengame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Letters_complete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_letters_complete);
    }
}