package com.example.childrengame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Eitan_game extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eitan_game);
    }
}